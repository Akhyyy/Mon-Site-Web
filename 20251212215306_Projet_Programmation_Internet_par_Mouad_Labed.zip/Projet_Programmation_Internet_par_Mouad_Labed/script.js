const menuToggle = document.getElementById('menuToggle');
const navMenu = document.getElementById('navMenu');

if (menuToggle && navMenu) {
    menuToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        menuToggle.classList.toggle('active');
    });

    
    const navLinks = document.querySelectorAll('.nav-menu a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            menuToggle.classList.remove('active');
        });
    });
}


const colorBtn = document.getElementById('colorBtn');
const textBtn = document.getElementById('textBtn');
const themeBtn = document.getElementById('themeBtn');
const demoBox = document.getElementById('demoBox');
const demoText = document.getElementById('demoText');


if (colorBtn) {
    colorBtn.addEventListener('click', () => {
        const colors = ['#3498db', '#2ecc71', '#9b59b6', '#e74c3c', '#f39c12'];
        const randomColor = colors[Math.floor(Math.random() * colors.length)];

        if (demoBox) {
            demoBox.style.borderColor = randomColor;
            demoBox.style.backgroundColor = `${randomColor}15`;

            if (demoText) {
                demoText.textContent = `Couleur chang�e en: ${randomColor}`;
                demoText.style.color = randomColor;
            }
        }
    });
}

if (textBtn) {
    let textSize = 1;

    textBtn.addEventListener('click', () => {
        textSize = textSize === 1 ? 1.2 : textSize === 1.2 ? 0.9 : 1;

        if (demoBox) {
            demoBox.style.fontSize = `${textSize}rem`;

            if (demoText) {
                demoText.textContent = `Taille du texte: ${textSize}rem`;
            }
        }
    });
}

if (themeBtn) {
    themeBtn.addEventListener('click', () => {
        document.body.classList.toggle('dark-theme');

        const icon = themeBtn.querySelector('i');
        if (document.body.classList.contains('dark-theme')) {
            icon.className = 'fas fa-sun';
            themeBtn.innerHTML = '<i class="fas fa-sun"></i> Mode clair';

            if (demoText) {
                demoText.textContent = 'Mode sombre activ�';
            }
        } else {
            icon.className = 'fas fa-moon';
            themeBtn.innerHTML = '<i class="fas fa-moon"></i> Mode sombre';

            if (demoText) {
                demoText.textContent = 'Mode clair activ�';
            }
        }

        localStorage.setItem('theme', document.body.classList.contains('dark-theme') ? 'dark' : 'light');
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
        if (themeBtn) {
            themeBtn.innerHTML = '<i class="fas fa-sun"></i> Mode clair';
        }
    }

    const animateOnScroll = () => {
        const cards = document.querySelectorAll('.feature-card, .cv-card, .personal-card');

        cards.forEach(card => {
            const cardTop = card.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;

            if (cardTop < windowHeight - 100) {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }
        });
    };

    const cards = document.querySelectorAll('.feature-card, .cv-card, .personal-card');
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    });

    setTimeout(animateOnScroll, 100);
    window.addEventListener('scroll', animateOnScroll);

    const skillBars = document.querySelectorAll('.skill-level');
    skillBars.forEach(bar => {
        const width = bar.style.width;
        bar.style.width = '0';

        setTimeout(() => {
            bar.style.width = width;
        }, 500);
    });
});

const darkThemeCSS = `
body.dark-theme {
    --primary: #1a252f;
    --secondary: #2980b9;
    --accent: #c0392b;
    --light: #34495e;
    --dark: #1a252f;
    --text: #ecf0f1;
    --bg: #2c3e50;
    --card-bg: #34495e;
    --shadow: 0 2px 10px rgba(0,0,0,0.3);
}
`;

const style = document.createElement('style');
style.textContent = darkThemeCSS;
document.head.appendChild(style);